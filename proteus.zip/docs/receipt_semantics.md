# Receipt Semantics (Normative)

This document defines when a receipt is considered **portable** and what is returned by `/record`.

## 1. STH cadence (MVP)
For MVP, the system MUST operate in **STH-per-append** mode:

- Each successful `/v1/manifests:record` appends exactly one leaf.
- The system computes the new Merkle root and issues a new STH immediately.
- The returned receipt MUST include:
  - the STH that **includes** the new leaf
  - the inclusion proof for the leaf in that STH

This ensures receipts are portable and verifiable without waiting for batching.

## 2. Leaf index assignment
- `leaf_index` is assigned at append time and is monotonically increasing per tenant log.
- `leaf_index` MUST be returned in the `/record` response.

## 3. Record response requirements
`POST /v1/manifests:record` MUST return:
- `manifest_id`
- `leaf_hash`
- `leaf_index`
- `sth` (tree_size, root_hash, issued_at, signature)
- `inclusion_proof`

## 4. Duplicate records (idempotency)
If a client submits an envelope that produces a `leaf_hash` that already exists in the tenant log:
- The system SHOULD return `200 OK` with the previously assigned `leaf_index`, `sth`, and `inclusion_proof`
- The system MUST NOT append a second identical leaf for the same `(tenant_id, leaf_hash)`.

## 5. Verification receipts
`POST /v1/manifests:verify` MUST return:
- signature verdict
- key status + revocation checked time
- inclusion verdict
- STH + inclusion proof (unless explicitly requested otherwise; default is to include)
