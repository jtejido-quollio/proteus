package logmem

import (
	"context"
	"encoding/hex"
	"sync"
	"time"

	"proteus/internal/domain"
	"proteus/internal/infra/merkle"
)

type Log struct {
	mu      sync.RWMutex
	tenants map[string]*tenantState
	clock   func() time.Time
	signSTH func(domain.STH) ([]byte, error)
}

type tenantState struct {
	leaves      [][]byte
	indexByHash map[string]int64
	sth         domain.STH
}

func New() *Log {
	return &Log{
		tenants: make(map[string]*tenantState),
		clock:   time.Now,
	}
}

func NewWithSigner(signSTH func(domain.STH) ([]byte, error)) *Log {
	return &Log{
		tenants: make(map[string]*tenantState),
		clock:   time.Now,
		signSTH: signSTH,
	}
}

func NewWithSignerAndClock(signSTH func(domain.STH) ([]byte, error), clock func() time.Time) *Log {
	if clock == nil {
		clock = time.Now
	}
	return &Log{
		tenants: make(map[string]*tenantState),
		clock:   clock,
		signSTH: signSTH,
	}
}

func (l *Log) AppendLeaf(ctx context.Context, tenantID string, leafHash []byte) (int64, domain.STH, domain.InclusionProof, error) {
	if err := ctx.Err(); err != nil {
		return 0, domain.STH{}, domain.InclusionProof{}, err
	}
	if len(leafHash) != merkle.HashSize {
		return 0, domain.STH{}, domain.InclusionProof{}, merkle.ErrInvalidHashLen
	}

	l.mu.Lock()
	defer l.mu.Unlock()

	state := l.ensureTenant(tenantID)
	index := int64(len(state.leaves))
	state.leaves = append(state.leaves, cloneHash(leafHash))

	key := hex.EncodeToString(leafHash)
	if _, ok := state.indexByHash[key]; !ok {
		state.indexByHash[key] = index
	}

	root, err := merkle.Root(state.leaves)
	if err != nil {
		state.leaves = state.leaves[:len(state.leaves)-1]
		return 0, domain.STH{}, domain.InclusionProof{}, err
	}
	path, err := merkle.InclusionProof(state.leaves, int(index))
	if err != nil {
		state.leaves = state.leaves[:len(state.leaves)-1]
		return 0, domain.STH{}, domain.InclusionProof{}, err
	}

	sth := domain.STH{
		TenantID: tenantID,
		TreeSize: int64(len(state.leaves)),
		RootHash: cloneHash(root),
		IssuedAt: l.clock().UTC(),
	}
	if l.signSTH != nil {
		sig, err := l.signSTH(sth)
		if err != nil {
			state.leaves = state.leaves[:len(state.leaves)-1]
			return 0, domain.STH{}, domain.InclusionProof{}, err
		}
		sth.Signature = sig
	}
	state.sth = sth

	inclusion := domain.InclusionProof{
		TenantID:    tenantID,
		LeafIndex:   index,
		Path:        path,
		STHTreeSize: sth.TreeSize,
		STHRootHash: cloneHash(root),
	}

	return index, sth, inclusion, nil
}

func (l *Log) GetInclusionProof(ctx context.Context, tenantID string, leafHash []byte) (int64, domain.STH, domain.InclusionProof, error) {
	if err := ctx.Err(); err != nil {
		return 0, domain.STH{}, domain.InclusionProof{}, err
	}

	l.mu.RLock()
	state := l.tenants[tenantID]
	if state == nil {
		l.mu.RUnlock()
		return 0, domain.STH{}, domain.InclusionProof{}, domain.ErrNotFound
	}
	index, ok := state.indexByHash[hex.EncodeToString(leafHash)]
	if !ok {
		l.mu.RUnlock()
		return 0, domain.STH{}, domain.InclusionProof{}, domain.ErrNotFound
	}
	leaves := state.leaves
	sth := state.sth
	l.mu.RUnlock()

	path, err := merkle.InclusionProof(leaves, int(index))
	if err != nil {
		return 0, domain.STH{}, domain.InclusionProof{}, err
	}
	if sth.TreeSize == 0 {
		root, err := merkle.Root(leaves)
		if err != nil {
			return 0, domain.STH{}, domain.InclusionProof{}, err
		}
		sth = domain.STH{
			TenantID: tenantID,
			TreeSize: int64(len(leaves)),
			RootHash: cloneHash(root),
			IssuedAt: l.clock().UTC(),
		}
	}

	inclusion := domain.InclusionProof{
		TenantID:    tenantID,
		LeafIndex:   index,
		Path:        path,
		STHTreeSize: sth.TreeSize,
		STHRootHash: cloneHash(sth.RootHash),
	}
	return index, sth, inclusion, nil
}

func (l *Log) GetConsistencyProof(ctx context.Context, tenantID string, fromSize, toSize int64) (domain.ConsistencyProof, error) {
	if err := ctx.Err(); err != nil {
		return domain.ConsistencyProof{}, err
	}
	if fromSize <= 0 || toSize <= 0 || fromSize > toSize {
		return domain.ConsistencyProof{}, merkle.ErrInvalidSize
	}

	l.mu.RLock()
	state := l.tenants[tenantID]
	if state == nil {
		l.mu.RUnlock()
		return domain.ConsistencyProof{}, domain.ErrNotFound
	}
	if toSize > int64(len(state.leaves)) {
		l.mu.RUnlock()
		return domain.ConsistencyProof{}, merkle.ErrInvalidSize
	}
	leaves := state.leaves[:toSize]
	l.mu.RUnlock()

	path, err := merkle.ConsistencyProof(leaves, int(fromSize), int(toSize))
	if err != nil {
		return domain.ConsistencyProof{}, err
	}

	return domain.ConsistencyProof{
		TenantID: tenantID,
		FromSize: fromSize,
		ToSize:   toSize,
		Path:     path,
	}, nil
}

func (l *Log) ensureTenant(tenantID string) *tenantState {
	state := l.tenants[tenantID]
	if state == nil {
		state = &tenantState{
			indexByHash: make(map[string]int64),
		}
		l.tenants[tenantID] = state
	}
	return state
}

func cloneHash(hash []byte) []byte {
	if hash == nil {
		return nil
	}
	out := make([]byte, len(hash))
	copy(out, hash)
	return out
}
