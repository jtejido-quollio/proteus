package usecase

import (
	"context"
	"errors"

	"proteus/internal/domain"
)

type RecordSignedManifestRequest struct {
	Envelope domain.SignedManifestEnvelope
}

type RecordSignedManifestResponse struct {
	ManifestID string
	LeafHash   []byte
	LeafIndex  int64
	STH        *domain.STH
	Inclusion  *domain.InclusionProof
	// InclusionProof included by default in Phase 1 implementation.
}

type RecordSignedManifest struct {
	Tenants TenantRepository
	Keys    KeyRepository
	Manif   ManifestRepository
	Log     TenantLog
	Crypto  CryptoService
}

func (uc *RecordSignedManifest) Execute(ctx context.Context, req RecordSignedManifestRequest) (*RecordSignedManifestResponse, error) {
	env := req.Envelope
	if err := validateManifest(env.Manifest); err != nil {
		return nil, err
	}
	if env.Signature.KID == "" || env.Signature.Value == "" {
		return nil, domain.ErrInvalidManifest
	}
	if env.Signature.Alg != "ed25519" {
		return nil, domain.ErrInvalidManifest
	}

	key, err := uc.Keys.GetByKID(ctx, env.Manifest.TenantID, env.Signature.KID)
	if err != nil {
		if errors.Is(err, domain.ErrNotFound) {
			return nil, domain.ErrKeyUnknown
		}
		return nil, err
	}

	revoked, err := uc.Keys.IsRevoked(ctx, env.Manifest.TenantID, env.Signature.KID)
	if err != nil {
		return nil, err
	}
	if revoked {
		return nil, domain.ErrKeyRevoked
	}

	canonical, err := uc.Crypto.CanonicalizeManifest(env.Manifest)
	if err != nil {
		return nil, err
	}
	if err := uc.Crypto.VerifySignature(canonical, env.Signature, key.PublicKey); err != nil {
		return nil, domain.ErrSignatureInvalid
	}

	leafHash, err := uc.Crypto.ComputeLeafHash(env)
	if err != nil {
		return nil, err
	}

	manifestID, _, err := uc.Manif.UpsertManifestAndEnvelope(ctx, env)
	if err != nil {
		return nil, err
	}

	leafIndex, sth, inclusion, err := uc.Log.AppendLeaf(ctx, env.Manifest.TenantID, leafHash)
	if err != nil {
		return nil, err
	}

	return &RecordSignedManifestResponse{
		ManifestID: manifestID,
		LeafHash:   leafHash,
		LeafIndex:  leafIndex,
		STH:        &sth,
		Inclusion:  &inclusion,
	}, nil
}

func validateManifest(manifest domain.Manifest) error {
	if manifest.Schema == "" {
		return domain.ErrInvalidManifest
	}
	if manifest.ManifestID == "" || manifest.TenantID == "" {
		return domain.ErrInvalidManifest
	}
	if manifest.Subject.Type == "" || manifest.Subject.MediaType == "" {
		return domain.ErrInvalidManifest
	}
	if manifest.Subject.Hash.Alg != "sha256" || manifest.Subject.Hash.Value == "" {
		return domain.ErrInvalidManifest
	}
	if manifest.Actor.Type == "" || manifest.Actor.ID == "" {
		return domain.ErrInvalidManifest
	}
	if manifest.Tool.Name == "" || manifest.Tool.Version == "" {
		return domain.ErrInvalidManifest
	}
	if manifest.Time.CreatedAt.IsZero() || manifest.Time.SubmittedAt.IsZero() {
		return domain.ErrInvalidManifest
	}
	return nil
}
